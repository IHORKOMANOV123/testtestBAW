<?php
class CalcResult {
    public $monthlyPayment;
}
?>
